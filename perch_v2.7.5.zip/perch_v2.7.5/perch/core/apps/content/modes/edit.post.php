<?php
    include __DIR__.'/'.$mode.'.post.php';
?>