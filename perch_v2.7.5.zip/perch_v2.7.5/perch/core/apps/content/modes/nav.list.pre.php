<?php

    $NavGroups = new PerchContent_NavGroups;

    $groups = $NavGroups->all();

    

?>