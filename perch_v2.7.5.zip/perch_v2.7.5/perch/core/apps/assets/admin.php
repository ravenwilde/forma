<?php
    $this->register_app('assets', 'Assets', 1.1, 'Asset management', $this->version);
?>