<?php

class PerchQuery
{
	public $select = '';
	public $from   = '';
	public $where  = array();
}