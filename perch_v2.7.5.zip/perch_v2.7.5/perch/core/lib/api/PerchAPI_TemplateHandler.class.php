<?php

class PerchAPI_TemplateHandler 
{
	public $tag_mask = '';

	public function render($vars, $html)
	{
		return $html;
	}

	public function render_runtime($html, $Template)
	{
		return $html;
	}
}
