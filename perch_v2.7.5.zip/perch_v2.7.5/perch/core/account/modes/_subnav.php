<?php
	echo PerchUtil::subnav($CurrentUser, array(
		array('page'=>'core/account', 'label'=>'My Account')
	));
?>