<?php
	$apps_list = array(
		'content', 
		'categories',
	);